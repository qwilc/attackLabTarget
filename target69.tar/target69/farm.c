/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_363()
{
    return 3284633928U;
}

void setval_442(unsigned *p)
{
    *p = 3284633928U;
}

void setval_266(unsigned *p)
{
    *p = 2445773128U;
}

void setval_130(unsigned *p)
{
    *p = 3281096792U;
}

void setval_319(unsigned *p)
{
    *p = 3281031512U;
}

void setval_401(unsigned *p)
{
    *p = 3281016843U;
}

unsigned getval_368()
{
    return 3251079496U;
}

void setval_178(unsigned *p)
{
    *p = 3281016924U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_103()
{
    return 3269495112U;
}

void setval_231(unsigned *p)
{
    *p = 3264269961U;
}

unsigned addval_100(unsigned x)
{
    return x + 3767093448U;
}

unsigned getval_271()
{
    return 2462222729U;
}

void setval_453(unsigned *p)
{
    *p = 2496760194U;
}

unsigned addval_133(unsigned x)
{
    return x + 3767101666U;
}

unsigned getval_456()
{
    return 3525365384U;
}

void setval_333(unsigned *p)
{
    *p = 3223372429U;
}

unsigned getval_281()
{
    return 2497743176U;
}

void setval_438(unsigned *p)
{
    *p = 2497743176U;
}

void setval_350(unsigned *p)
{
    *p = 3375940233U;
}

unsigned getval_409()
{
    return 3281048009U;
}

void setval_390(unsigned *p)
{
    *p = 2464188744U;
}

unsigned addval_301(unsigned x)
{
    return x + 3232023177U;
}

void setval_294(unsigned *p)
{
    *p = 2109984409U;
}

void setval_249(unsigned *p)
{
    *p = 3348156041U;
}

void setval_428(unsigned *p)
{
    *p = 4173581961U;
}

unsigned getval_316()
{
    return 3247493513U;
}

void setval_377(unsigned *p)
{
    *p = 2430634248U;
}

void setval_164(unsigned *p)
{
    *p = 3229929865U;
}

unsigned getval_313()
{
    return 3674263945U;
}

unsigned getval_221()
{
    return 3525889673U;
}

unsigned getval_416()
{
    return 3374894729U;
}

unsigned addval_216(unsigned x)
{
    return x + 2425475465U;
}

unsigned addval_237(unsigned x)
{
    return x + 3682128265U;
}

unsigned getval_425()
{
    return 3374371209U;
}

unsigned addval_191(unsigned x)
{
    return x + 2430634312U;
}

unsigned getval_265()
{
    return 3284306220U;
}

unsigned addval_169(unsigned x)
{
    return x + 3267529052U;
}

void setval_283(unsigned *p)
{
    *p = 3676360329U;
}

unsigned addval_327(unsigned x)
{
    return x + 3374891657U;
}

unsigned addval_111(unsigned x)
{
    return x + 3381969545U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
